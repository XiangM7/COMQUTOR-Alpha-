# T2 — John's seven required scenarios → the tests that prove them

Source: COMQUTOR Alpha 下一轮开发任务单, 四、T2, 3. 必须提供的自动测试 (7 scenarios)

> Tests of kind engine_level and end_to_end_formal_status use hand-made (SYNTHETIC) inputs and are never counted as real market validation. Tests of kind upstream_real_path run real production code; whether their inputs are hand-made or saved runs is stated in each test.

Kinds: **engine (synthetic)** = one rule function or the engine, synthetic inputs; **final status (synthetic)** = run_formal_acceptance / production wiring, synthetic inputs, asserts the final status; **upstream real code** = the real production code that feeds the engine

The map is checked by `tests/test_t2_scenario_map_points_at_real_tests.py`: every test cited below exists.

## 1. 有明确支持证据，却漏掉必须识别的 Alpha → 验收能够发现漏检

| Kind | Test | What it proves |
|---|---|---|
| engine (synthetic) | `tests/test_acceptance_engine.py::TestScenarioA_MissedRequiredPairIsDetected::test_a_clear_support_but_missed_required_pair_is_reported_as_fail` | evidence on both sides + required pair not admitted -> fail (rule function) |
| final status (synthetic) | `tests/test_t2_rule_config_errors.py::test_scenario_a_a_required_pair_with_evidence_on_both_sides_that_was_not_admitted_is_a_formal_fail` | the same case changes the FINAL formal_status to fail and names the pair in failure_reasons |
| upstream real code | `tests/test_t2_acceptance_engine_qualified_evidence_scenarios.py::TestScenarioC_ValidSupportGenuinelyCounts::test_a_real_reviewed_bear_source_makes_evidence_present_flip_to_true` | through the real pipeline a reviewed source makes evidence_present flip to true |

*Limit:* Implemented for required CONFLICT PAIRS (v0.2 required_conflicts). John's sentence says Alpha; no rule file declares a list of required Alphas, and the v0.2 contract says a missing structural Alpha never fails a run. Open question for John, recorded in the T2 report.

## 2. 没有支持证据 → 不强制激活 Alpha 或生成冲突

| Kind | Test | What it proves |
|---|---|---|
| engine (synthetic) | `tests/test_acceptance_engine.py::TestScenarioB_NoEvidenceNeverForcesDetection::test_b_no_supporting_evidence_never_forces_activation_or_a_conflict` | no arbitration entry -> not_applicable (rule function) |
| final status (synthetic) | `tests/test_t2_rule_config_errors.py::test_scenario_b_a_required_pair_without_supporting_evidence_is_never_forced_into_a_fail` | FINAL formal_status is not fail (before 2026-10-07 the legacy v0.2 view leaked into it and forced a fail) |
| final status (synthetic) | `tests/test_t2_rule_config_errors.py::test_scenario_b_one_sided_evidence_is_not_enough_to_force_a_fail` | evidence on one side only is still not enough to require detection |
| upstream real code | `tests/test_conflict_admissibility.py::test_c_single_unique_supporting_fact_is_insufficient` | B2 itself does not admit a pair on a single supporting fact |

## 3. 只有反驳、引用或背景文字 → 不当成该 Alpha 的有效支持

| Kind | Test | What it proves |
|---|---|---|
| engine (synthetic) | `tests/test_acceptance_engine.py::TestScenarioC_OpposingOrBackgroundEvidenceNeverCountsAsSupport::test_c_zero_stance_confirmed_support_never_counts_as_evidence_present` | a zero supporting count is 'no evidence present' (injected count) |
| upstream real code | `tests/test_conflict_admissibility.py::test_e_opposes_alpha_stance_does_not_count_as_support` | real B2: an opposing stance is not support |
| upstream real code | `tests/test_conflict_admissibility.py::test_f_mentions_alpha_stance_does_not_count_as_support` | real B2: a mere mention / citation is not support |
| upstream real code | `tests/test_conflict_admissibility.py::test_g_neutral_background_stance_does_not_count_as_support` | real B2: neutral background is not support |
| upstream real code | `tests/test_conflict_admissibility.py::test_h_supports_counter_alpha_stance_does_not_count_as_support` | real B2: support for the OTHER side is not support |
| upstream real code | `tests/test_t2_acceptance_engine_qualified_evidence_scenarios.py::TestScenarioA_InvalidSourceNeverCountsAsQualifyingEvidence::test_forged_bear_marker_leaves_bear_supporting_evidence_count_at_zero` | through the real pipeline a forged source never counts |
| upstream real code | `tests/test_t2_acceptance_engine_qualified_evidence_scenarios.py::TestScenarioB_PendingReviewNeverCountsAsQualifyingEvidence::test_a_real_valid_but_unreviewed_bear_source_leaves_bear_supporting_evidence_count_at_zero` | through the real pipeline an unreviewed source never counts |

*Limit:* The engine reads B2's supporting-evidence count; that opposing / citation / background text is excluded from that count is proven by the upstream tests listed.

## 4. 必需规则缺失或无法执行 → 报错，不产生正式 PASS

| Kind | Test | What it proves |
|---|---|---|
| engine (synthetic) | `tests/test_acceptance_engine.py::TestScenarioD_MissingConfigBlocksFormalPass::test_d_missing_label_file_is_a_config_error_never_a_formal_pass` | missing label file -> config_error |
| engine (synthetic) | `tests/test_acceptance_engine.py::TestScenarioD_MissingConfigBlocksFormalPass::test_d_missing_taxonomy_file_is_a_config_error_never_a_formal_pass` | missing taxonomy file -> config_error |
| final status (synthetic) | `tests/test_t2_rule_config_errors.py::test_a_taxonomy_that_lacks_the_pairs_the_label_declares_is_a_config_error_not_a_silent_acceptance` | taxonomy incompatible with the label file -> config_error |
| final status (synthetic) | `tests/test_t2_rule_config_errors.py::test_a_label_file_written_against_another_taxonomy_content_version_is_a_config_error` | version mismatch -> config_error |
| final status (synthetic) | `tests/test_t2_rule_config_errors.py::test_a_rule_key_the_engine_does_not_implement_is_a_config_error_that_names_it` | rule type not implemented -> config_error |
| final status (synthetic) | `tests/test_t2_rule_config_errors.py::test_a_ticker_with_no_declared_rules_is_a_config_error_never_a_pass` | a ticker the rule file says nothing about -> config_error, never PASS |
| final status (synthetic) | `tests/test_t2_rule_config_errors.py::test_an_unusable_rule_file_leaves_a_visible_config_error_artifact` | in production a broken rule file leaves a visible config_error artifact |
| final status (synthetic) | `tests/test_t2_rule_config_errors.py::test_an_unexpected_failure_leaves_a_visible_execution_error_artifact` | in production an unexpected failure leaves a visible execution_error artifact |
| engine (synthetic) | `tests/test_acceptance_engine.py::TestScenarioI_SemanticInputGateNeverSilentlyDefaultsToPass::test_missing_alpha_matches_payload_is_never_a_pass` | missing semantic input -> alpha_semantic_unavailable, never PASS |

## 5. 同源证据增加多份重复表达 → 不重复抬高证据强度

| Kind | Test | What it proves |
|---|---|---|
| engine (synthetic) | `tests/test_acceptance_engine.py::TestScenarioE_DuplicateCitationNeverInflatesEvidence::test_e_engine_only_ever_reads_the_already_deduped_fact_group_count` | the engine only reads B2's already-deduplicated count (injected count) |
| upstream real code | `tests/test_conflict_admissibility.py::test_d_three_near_duplicate_claims_count_as_one_not_three` | real B2: three near-duplicate claims count as one fact |
| upstream real code | `tests/test_content_support_llm_production_wiring.py::test_duplicate_source_citation_across_two_claims_does_not_inflate_independent_evidence_count` | real pipeline: one source cited by two claims does not inflate the independent evidence count |
| upstream real code | `tests/test_structure_correctness_sprint.py::test_same_source_duplicate_claims_are_merged` | real structure code: same-source duplicate claims merge |
| upstream real code | `tests/test_structure_correctness_sprint.py::test_duplicate_claims_do_not_inflate_matched_evidence` | real structure code: duplicates do not inflate matched evidence |

*Limit:* The deduplication itself lives upstream (evidence facts / B2) and is proven there; the engine test only pins that the engine adds no second count.

## 6. 实际冲突不在标的验收列表 → 保留研究输出，转入复核，不改答案

| Kind | Test | What it proves |
|---|---|---|
| final status (synthetic) | `tests/test_acceptance_engine.py::TestScenarioF_OutOfListConflictKeptVisible::test_f_admitted_conflict_outside_every_declared_category_is_never_dropped` | an admitted undeclared pair -> needs_review (not fail), research output untouched |
| final status (synthetic) | `tests/test_t2_rule_config_errors.py::test_an_undeclared_admitted_conflict_is_a_review_reason` | the undeclared pair is listed in review_reasons that explain the status |

*Limit:* On the six saved runs the same mechanism routes NVDA A304__A601 and QQQ A501__A601 etc. to review (see the six-ticker verdicts and the open-review ledger).

## 7. 同一输入做纯 replay，只更换执行编号 → 不因 run_id 变化产生无依据的研究结论变化

| Kind | Test | What it proves |
|---|---|---|
| engine (synthetic) | `tests/test_acceptance_engine.py::TestScenarioG_PureReplayIsDeterministic::test_g_identical_input_replayed_under_a_different_run_id_yields_identical_verdicts` | the acceptance verdict does not depend on run_id |
| upstream real code | `tests/test_replay_pipeline.py::TestReplayCore::test_two_identical_replays_are_deterministic` | two identical replays give identical results |
| upstream real code | `tests/test_replay_identity_correction.py::test_conflict_detector_receives_replay_run_id_and_zero_mismatches` | the replay run_id reaches the conflict detector with zero mismatches |
| upstream real code | `tests/test_artifact_export_and_api.py::test_replay_conflict_does_not_get_run_id_mismatch` | a replayed conflict payload does not get a run_id mismatch |
| upstream real code | `tests/replay/test_exact_semantic_replay.py::test_eligible_exact_replay_is_atomic_byte_identical_and_source_read_only` | exact semantic replay is byte-identical and read-only on the source |

*Limit:* The engine's own test is trivially true (run_id never enters a verdict); the research-conclusion property is carried by the upstream replay tests.
