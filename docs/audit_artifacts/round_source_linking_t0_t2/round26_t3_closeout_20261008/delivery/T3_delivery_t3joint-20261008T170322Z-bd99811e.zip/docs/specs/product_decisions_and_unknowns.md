# Product Decisions and Unknowns Register

## PD-001 — Canonical Development Plan v1.0 Copy and SHA

- **Status:** `RESOLVED`
- **Source:** Product-provided local DOCX; `docs/specs/development_plan_v1.0_manifest.json`
- **Owner:** Product owner / repository maintainers
- **Impact:** Establishes the only repository source that may be cited as Development Plan v1.0 `SOURCE_FROZEN`.
- **Blocking phase:** None for Phase 0.5
- **Required resolution:** Preserve the byte-identical file at SHA-256 `cabf3381aaa633b7b88035ab6df2d7dac0def3d5ddd337f6384f23f4c439a8d9`; add future versions separately.

## PD-002 — Semantic Authority Target Architecture

- **Status:** `APPROVED_PROJECT_DECISION`
- **Source:** ADR-001
- **Owner:** Product owner / architecture owner
- **Impact:** Separates LLM semantic proposal from deterministic validation/admission/scoring authority.
- **Blocking phase:** Phases 1–4
- **Required resolution:** Implement only through the gated future-phase contract; Phase 0.5 performs no enforcement.

## PD-003 — TradingAgents Canonical Prompt Injection

- **Status:** `FUTURE_REMOVAL_OR_DISABLEMENT_APPROVED; RUNTIME_CHANGE_DEFERRED`
- **Source:** Development Plan v1.0 L1/L2 as-is and output-capture-hooks boundary; ADR-002
- **Owner:** Product owner / architecture owner
- **Impact:** Current active prompt modification is not future production authority, but immediate removal could change Graph/Activation/Conflict.
- **Blocking phase:** Phase 4
- **Required resolution:** Measure canonical-edge effects, establish a no-injection baseline, and approve flagged rollout plus rollback before changing runtime.

## PD-004 — Exact Semantic Replay vs Raw Rebuild Diagnostic

- **Status:** `APPROVED_PROJECT_DECISION`
- **Source:** ADR-003
- **Owner:** Architecture owner
- **Impact:** Prevents raw deterministic rebuild from being represented as exact replay of historical LLM-tier decisions.
- **Blocking phase:** Phase 0.6
- **Required resolution:** Freeze and implement persisted semantic artifacts, explicit mode names, completeness policy, and Provider-zero invariants.

## PD-005 — John's 20 Alpha Mapper Labels

- **Status:** `BLOCKED_BY_PRODUCT_OWNER`
- **Source:** Development Plan v1.0 §5.2 and Week 2 acceptance
- **Owner:** John / product owner
- **Impact:** Formal ≥80% Alpha Mapper acceptance cannot be completed.
- **Blocking phase:** Phase 2 production cutover
- **Required resolution:** Supply the original 20 labeled claims, labels, rubric, version, and sign-off owner; do not substitute a locally invented set.

## PD-006 — Evidence Stance LLM Authority

- **Status:** `NOT_APPROVED`
- **Source:** `JOHN_LATER_REQUIREMENT`; ADR-004
- **Owner:** John / product owner
- **Impact:** Evidence Stance remains deterministic shadow and cannot affect Activation or Conflict.
- **Blocking phase:** Addendum A and Phase 5
- **Required resolution:** Approve a separate versioned addendum defining proposer/validator/fallback authority and evaluation gates.

## PD-007 — Ticker Specificity Definition

- **Status:** `NOT_APPROVED`
- **Source:** Not defined in Development Plan v1.0; current review limitation
- **Owner:** John / product owner
- **Impact:** No reliable ticker-specificity classification or production evidence gate exists.
- **Blocking phase:** Addendum A and Phase 5
- **Required resolution:** Define categories, peer/reference handling, ambiguity, abstention, examples, gold set, and acceptance thresholds.

## PD-008 — Historical LLM-Enabled Runs

- **Status:** `UNKNOWN_NOT_ENUMERATED`
- **Source:** Phase 0 replay audit
- **Owner:** Engineering / audit owner
- **Impact:** The historical prevalence of LLM-tier semantic decisions and exact-replay exposure is unknown.
- **Blocking phase:** Phase 0.6 planning; Phase 4 migration baseline
- **Required resolution:** Read-only enumerate run metadata and record whether `COMQUTOR_WEEK2_LLM_ENABLED=true` was realized, without modifying artifacts.

## PD-009 — Real Per-Run/Fleet-Wide LLM Call Count

- **Status:** `UNKNOWN_NOT_INSTRUMENTED`
- **Source:** Phase 0 Provider-call baseline
- **Owner:** Engineering / observability owner
- **Impact:** Cost, latency, duplicate-call, and budget baselines cannot be stated as measured facts.
- **Blocking phase:** Phase 0.6 and later cutovers
- **Required resolution:** Persist semantic call records and aggregate provider/task counts without enabling production LLM by default.

## PD-010 — LLM Response Cache

- **Status:** `MISSING`
- **Source:** Development Plan v1.0 §6, §7 non-functional requirements, and Week 5; Phase 0 code audit
- **Owner:** Phase 0.6 execution-substrate owner
- **Impact:** Duplicate semantic inputs may trigger repeated calls when the optional LLM tier is enabled.
- **Blocking phase:** Phase 0.6
- **Required resolution:** Define stable cache identity, validation/version invalidation, privacy/retention, observability, and replay interaction before cutover.

## PD-011 — §5.2 Alpha Mapping Cardinality

- **Status:** `APPROVED_PROJECT_DECISION`
- **Source:** Product Owner directive, closing the Development Plan v1.0 §5.2/§10 singular ("matched_alpha") vs. plural ("matched_alphas") inconsistency identified by the §5.2 implementation precheck
- **Owner:** Product owner
- **Decision:** A structured Claim has exactly ONE authoritative primary Alpha (`matched_alpha`), plus up to TWO informational, non-authoritative secondary Alpha candidates (`secondary_alphas`). `PRIMARY_ALPHA_COUNT <= 1`; `SECONDARY_ALPHA_COUNT <= 2`; `TOTAL_RETAINED_ALPHA_CANDIDATES <= 3`. Secondary Alphas are never co-authoritative with the primary.
- **Impact:** Resolves the `AMBIGUOUS` "output cardinality" gap-table row from the §5.2 precheck. No schema/persistence change required — see `section_5_2_product_decisions_and_john_gold_provenance.md` §Cardinality Audit.
- **Blocking phase:** Phase 2 (§5.2 formal acceptance)
- **Required resolution:** None outstanding. Future implementation work must not redesign `matched_alpha` into a multi-authoritative-alpha schema.

## PD-012 — §5.2 Alpha Score Semantics and Claim Confidence Role

- **Status:** `APPROVED_PROJECT_DECISION`
- **Source:** Product Owner directive
- **Owner:** Product owner
- **Decision:** The §5.2 Alpha match score represents semantic relevance of the Claim to the Alpha ONLY — never claim truth probability, evidence reliability, claim confidence, activation strength, or investment conviction. §5.1 Claim `confidence` must not be multiplied into or otherwise used to modify the Alpha relevance score; it may continue to be carried as metadata only.
- **Impact:** Resolves the `AMBIGUOUS` "confidence role" item from the §5.2 precheck. Current implementation already complies (confidence is not read anywhere in `alpha_mapper.py`) — no code change required.
- **Blocking phase:** None (already satisfied)
- **Required resolution:** None.

## PD-013 — §5.2 Global Minimum Match Threshold

- **Status:** `APPROVED_PROJECT_DECISION`
- **Source:** Development Plan v1.0 §5.2 ("threshold 0.35"), reaffirmed by explicit Product Owner directive
- **Owner:** Product owner
- **Decision:** 0.35 is the uniform minimum Alpha match threshold for all 10 canonical Alphas. The existing A101/A102/A103 independent hard-gate threshold bypass (`comqutor_alpha/structure_engine/ai_alpha_discriminator.py`, consumed at `alpha_mapper.py`'s `eligible_candidates` filter) has no Product Owner or ADR approval found anywhere in the repository — see `section_5_2_product_decisions_and_john_gold_provenance.md` §AI-Alpha Hard Gate Audit — and is therefore `NOT_APPROVED`. Unless a genuine prior or later approval is separately discovered, the future implementation alignment target is `ALL_10_ALPHAS_USE_0_35_MINIMUM_MATCH_THRESHOLD`.
- **Impact:** Closes the "AI-alpha threshold carve-out" spec/code conflict from the §5.2 precheck.
- **Blocking phase:** Phase 2 (§5.2 formal acceptance) — implementation alignment itself is a future task, not performed by this decision record.
- **Required resolution:** A future implementation task must remove or align the A101/A102/A103 carve-out to the uniform 0.35 threshold.

## PD-014 — §5.2 No-Match Behavior

- **Status:** `APPROVED_PROJECT_DECISION`
- **Source:** Product Owner directive
- **Owner:** Product owner
- **Decision:** A valid §5.1 structured Claim with no Alpha at or above threshold must be retained (never dropped) with `matched_alpha = null` and its existing explicit no-match status. No fake "NONE" Alpha; no forcing a low-confidence Alpha through the threshold.
- **Impact:** Resolves the "no-match behavior" item (not found in the frozen plan) from the §5.2 precheck. Current implementation already complies — no code change required.
- **Blocking phase:** None (already satisfied)
- **Required resolution:** None.

## PD-015 — §5.2 Tier-2 LLM Classifier Authority Graduation Condition

- **Status:** `APPROVED_PROJECT_DECISION`
- **Source:** Product Owner directive, formalizing the pre-existing `docs/specs/semantic_authority_matrix.csv` "PRODUCT_VALIDATION_MISSING" gate and PD-005 as an explicit decision record
- **Owner:** Product owner
- **Decision:** The Tier-2 LLM classifier (code-complete, already wired to the shared Week2LLMGateway) does not receive production semantic authority merely because it exists. It graduates only after (a) the authentic Product Owner benchmark (PD-005) becomes available and (b) the approved §5.2 acceptance metric (PD-016) reaches ≥80% against it. Until then: `TIER_2_IMPLEMENTATION = CODE_COMPLETE`, `TIER_2_AUTHORITY = PRODUCT_VALIDATION_PENDING`.
- **Impact:** No change to current runtime behavior (Tier-2 already gated behind `COMQUTOR_WEEK2_LLM_ENABLED`, off by default); makes explicit as a Product Decision what was previously stated only in a non-PD architecture document.
- **Blocking phase:** Phase 2 production cutover
- **Required resolution:** Same as PD-005 — an authentic Product Owner benchmark must be supplied and pass.

## PD-016 — §5.2 Evaluation Metric (Conditional on Authentic Benchmark Label Format)

- **Status:** `APPROVED_PROJECT_DECISION (conditional — not yet applicable, see PD-005)`
- **Source:** Product Owner directive
- **Owner:** Product owner
- **Decision:** IF the authentic John-approved benchmark (PD-005) is confirmed single-label (exactly one canonical expected primary Alpha per Claim), THEN the §5.2 acceptance metric is `TOP_1_EXACT_PRIMARY_ALPHA_ACCURACY`: a prediction counts correct only when predicted `matched_alpha` equals John's expected primary Alpha exactly (Top-3/secondary-alpha hits do not count; F1/precision/recall/weighted/semantic-similarity substitutes are not approved), and the pass condition for a 20-claim set is `>=16/20`. IF the authentic benchmark is genuinely multi-label or uses different label semantics, this metric does NOT apply and a new Product Owner decision is required before evaluation.
- **Impact:** Pre-resolves the metric-definition ambiguity from the §5.2 precheck, conditionally. Cannot yet be applied to produce an acceptance result — the authentic benchmark itself remains unverified/missing per PD-005.
- **Blocking phase:** Phase 2 production cutover
- **Required resolution:** Confirm the authentic benchmark's label format once supplied by the product owner; if single-label, this metric applies without further decision-making.

## PD-017 — MSFT A102__A304 Canonical Conflict Taxonomy Adjudication

- **Status:** `REJECTED_BY_INDEPENDENT_LLM_ADJUDICATION`
- **Source:** User-authorized independent LLM product adjudication (Coding Agent, task `MSFT_A102_A304_TAXONOMY_ADJUDICATION`). **No human review was performed. John did not personally review or approve this decision.** The user explicitly authorized the Coding Agent to make this specific taxonomy judgment call without per-item human sign-off.
- **Owner:** User-authorized independent LLM adjudication — not a human Product Owner decision. Any future human Product Owner (including John) may reopen or override this record.
- **Decision:** `A102__A304` (Inference Explosion vs. Multiple Compression) is **not added** to the canonical conflict taxonomy (`comqutor_alpha/alpha_library/alpha_taxonomy_v1.yaml`). `alpha_taxonomy_v1.yaml` remains byte-identical; A102's `conflict_alphas` remains `[]`. The MVP taxonomy's canonical conflict-pair set remains exactly the six pairs `MANDATORY_CONFLICT_WEIGHTS` in `comqutor_alpha/alpha_library/alpha_loader.py` already enforces: A101–A304, A301–A304, A001–A501, A003–A501, A601–A304, A601–A501.
- **Reasoning:**
  1. **Alpha definitions (rank-1 authority).** A102 ("Inference Explosion") is a Theme-layer demand/growth driver whose own `relations` are exclusively `supportive` — to A103 (weight 0.80) and A301 (weight 0.70) — never to A304. A304 ("Multiple Compression") is a Valuation-layer risk driver whose `conflict_alphas` explicitly names A101, A301, and A601 — never A102. Neither canonical definition declares a tension between these two specific Alphas.
  2. **No approved Product Decision or ADR (rank-2 authority) exists for this pair.** PD-001 through PD-016 and ADR-001 through ADR-010 were searched; none addresses `A102__A304` or MSFT's conflict-pair set. PD-013 addresses a different, unrelated A101/A102/A103 matter (the Alpha *matching*-threshold carve-out in `ai_alpha_discriminator.py`), not conflict-pair declaration.
  3. **The canonical conflict taxonomy contract (rank-3 authority) deliberately excludes A102 from every conflict.** `alpha_taxonomy_v1.yaml` gives A102 `conflict_alphas: []`, structurally identical to A103 (AI Infrastructure) and A201 (Semiconductor Supercycle) — the taxonomy's design pattern lets A304 conflict with exactly one representative Alpha per causal layer that terminates a growth thesis (A101 = Theme-top, A301 = Fundamental-terminal, A601 = Sentiment cross-cutting), deliberately omitting the supportive chain-input Alphas (A102, A103, A201) that feed into A101/A301 via `relations` rather than duplicating the same tension at every layer. `alpha_loader.py`'s `MANDATORY_CONFLICT_WEIGHTS` hard-codes exactly six pairs and `validate_taxonomy` enforces them as mandatory; treating this set as closed (not "at least six, more allowed on demand") is consistent with the whole MVP-10 taxonomy's frozen-contract history (see `docs/adr/*`, `docs/specs/development_plan_v1.0_reference_index.md`).
  4. **The Development Plan v1.0 (rank-4 authority, `SOURCE_FROZEN` per PD-001) is internally self-contradictory on this exact point**, and the contradiction cannot be resolved in A102__A304's favor without overriding the higher-ranked taxonomy contract above it. §4 states "Conflict (all six are mandatory in MVP): A101 vs A304 · A301 vs A304 · A001 vs A501 · A003 vs A501 · A601 vs A304 · A601 vs A501" — A102 vs A304 is not one of the six. §12's "Golden Test Cases" table (attributed to "John supplies expectations") lists MSFT's "Expected main conflict" as "Bull A102 vs Bear A304" — the only one of the three worked golden rows (NVDA: A101 vs A304; QQQ: A001 vs A501; MSFT: A102 vs A304) that does not name one of §4's own six mandatory pairs. MSFT's own "Expected dominant alphas" cell in the same row already lists A101 (`A101, A102, A301, A304`), so a MSFT main-conflict of "Bull A101 vs Bear A304" — consistent with NVDA's row and with §4 — was directly available from the same table without inventing anything. Given A101/A102 are adjacent, similarly-named Theme-layer IDs ("AI Expansion" / "Inference Explosion"), the far more parsimonious reading is a drafting slip in §12, not a deliberate, reasoned decision to special-case MSFT's conflict pair — nothing elsewhere in the Development Plan explains *why* MSFT specifically would need a distinct conflict pair from every other AI-exposed ticker.
  5. **Saved production artifacts (rank-5 authority) provide no supporting signal.** The one available MSFT saved run with a completed offline replay (`0cb43bae-1a4d-4003-bb29-55d420498842`, `deterministic_baseline` stance source, `artifact_completeness=fail`) shows A102 at `activation_score=0.0`, `evidence_count=0`, `ticker_specific_evidence_count=0` — no claim in that run mapped to A102 at all. This is not treated as proof the pair "doesn't exist" (a single incomplete run cannot prove that), only as the absence of any empirical push toward approval.
  6. **Approving the pair risks uncontrolled taxonomy expansion.** A102's own reasoning applies equally to A103 (AI Infrastructure) and A201 (Semiconductor Supercycle) — both are structurally identical "supportive chain-input, zero declared conflicts" Theme/Infrastructure/Industry Alphas. Approving `A102__A304` on the general "any AI-growth Alpha can conflict with valuation risk" logic would create pressure to also add `A103__A304` and `A201__A304`, which is exactly the semantic over-generalization / duplicate-conflict risk this adjudication was asked to guard against (the tension A102 might carry against A304 is already transitively expressed via the existing A301↔A304 pair, since A102 →(supports 0.70)→ A301 →(conflicts 0.85)→ A304).
  7. **Not ticker-general.** The only evidence favoring approval is a single MSFT-specific line in one golden-case table, not a general Alpha-to-Alpha semantic argument that would apply the same way to every other A102-exposed ticker (e.g. NVDA, AMD). Per this task's own instruction, a pair that "only seems reasonable for one ticker, without general structural meaning for others" should not enter the canonical taxonomy.
- **Impact:** `J2_V0.2` for MSFT: `A102__A304` moves from `product_decision_pending` to `remove_while_undeclared` (see `comqutor_alpha/config/j2_provisional_regression_labels_v0.2.yaml`) — a formally rejected, non-canonical, non-executable pair, distinct from the still-open "pending" status it carried before this adjudication. `J2_v0.1` (`j2_provisional_regression_labels_v0.1.yaml`) is left byte-identical as a frozen historical snapshot, consistent with its existing "preserved, never superseded" status. `alpha_taxonomy_v1.yaml` is byte-identical (no code or schema change was needed in `comqutor_alpha/regression/evaluation_contract.py` — `remove_while_undeclared` pairs were already surfaced informationally regardless of ticker evaluability by the existing J2 v0.2 evaluator).
- **Blocking phase:** None — this closes a previously-open `product_decision_pending` item; it does not block any phase.
- **Required resolution:** None outstanding for this pair. A future human Product Owner (John or delegate) may reopen this decision with new formal evidence (e.g. an explicit ADR, a corrected Development Plan addendum, or a substantive general Alpha-semantics argument extending beyond MSFT) — until then, `A102__A304` must not be silently reintroduced as an executable (`required`/`conditional`/`allowed`) conflict via any future provisional label file; `comqutor_alpha/regression/labels_v2.py`'s existing `LABEL_V2_UNDECLARED_EXECUTABLE_CONFLICT_PAIR` validation already enforces this structurally for as long as the pair remains outside the canonical taxonomy.

## PD-017-REVISED — A102__A304 and A201__A304 Reopened and Approved as Conditional Conflict Pairs

- **Status:** `APPROVED_CONDITIONAL` — supersedes PD-017's `REJECTED_BY_INDEPENDENT_LLM_ADJUDICATION` status for `A102__A304`, and additionally resolves the parallel, previously-undeclared `A201__A304` gap (SNDK/TSM/AMD) recorded in `docs/audit_artifacts/v0_2_john_frozen_gold_baseline.yaml`'s `implementation_alignment_required` section. This entry does not delete or rewrite PD-017 above — both are preserved so the full decision history remains inspectable.
- **Source:** Explicit user instruction ("COMQUTOR Alpha 下一轮开发任务单", task section T2, item 1: "补齐已确认关系 … 将 A102__A304、A201__A304 作为有条件可评估的关系接入实际 taxonomy"), naming both pairs explicitly as already-confirmed relationships to bring into the taxonomy. This is the same authorization mechanism PD-017 itself used ("User-authorized independent LLM product adjudication … The user explicitly authorized the Coding Agent to make this specific taxonomy judgment call") — a direct, explicit user instruction naming the exact pairs, not an inferred or self-initiated re-derivation of PD-017's own reasoning. **No independent human Product Owner review beyond this instruction was performed; John did not personally re-review PD-017's original analysis.** This does not meet PD-017's own stated bar for reopening ("an explicit ADR, a corrected Development Plan addendum, or a substantive general Alpha-semantics argument") in written-artifact form — it is recorded here as a plain, explicit user directive, and PD-017's own analytical reasoning (still fully preserved above) should be re-examined by a human Product Owner if that formal bar needs to be satisfied later.
- **Decision:** `A102__A304` and `A201__A304` are added to `comqutor_alpha/alpha_library/alpha_taxonomy_v1.yaml` as reciprocal `conflict_alphas` declarations (A102↔A304 and A201↔A304, `contradiction_weight: 0.75` each side — see the taxonomy file's own `content_change_log` block for the full weight rationale). Both moved from `remove_while_undeclared` to `conditional_conflicts` in `comqutor_alpha/config/j2_provisional_regression_labels_v0.2.yaml` for every affected ticker (MSFT for A102__A304; SNDK, TSM, AMD for A201__A304).
- **What this does NOT mean:** Declaring a pair evaluable is not the same as it being admitted, dominant, or a main conflict for any given run. The existing, unmodified, ticker-agnostic evidence-driven admissibility gate (`comqutor_alpha/conflict_engine/conflict_admissibility.py`: `ALPHA_SCORE_THRESHOLD=50.0`, `MIN_SUPPORTING_EVIDENCE_PER_SIDE=2`, `MIN_TICKER_SPECIFIC_SUPPORT_PER_SIDE=1`) still governs whether either pair is ever actually admitted for a specific run — exactly as for every other declared pair. This is why both are classified under the `conditional_only` rule family (evaluable, never mandatory, an informational miss rather than a failure if not detected) rather than `required_conflicts` or `allowed_conflicts`.
- **Impact:** `tests/test_msft_a102_a304_taxonomy_adjudication.py` (originally written to lock in PD-017's `REJECT_PAIR` outcome) has been updated in the same commit-equivalent change to assert the new `APPROVED_CONDITIONAL` state instead of the old rejection, including a refreshed `FROZEN_HASHES[TAXONOMY_PATH]` pin (a legitimate re-pin: the taxonomy content change is exactly what this decision authorizes, not an unrelated/unauthorized drift). PD-017's own six-point reasoning (Alpha-definition-relations argument, no-prior-PD/ADR argument, taxonomy-design-pattern argument, Development-Plan-contradiction argument, saved-artifact-signal argument, uncontrolled-expansion-risk argument) is not rebutted point-by-point here — it is superseded by explicit instruction, and remains available for a human Product Owner to weigh if this decision is revisited again.
- **Blocking phase:** None.
- **Required resolution:** None outstanding. If a future human Product Owner wants to restore PD-017's original `REJECT_PAIR` state, that is a taxonomy content change symmetric to this one (remove the two `conflict_alphas` entries, move the pairs back to `remove_while_undeclared`) — not a code change.
- **Addendum (2026-10-07, T2 completion):**
  - *Version:* the taxonomy file now carries `content_version: "1.1.0"` (this change = 1.0.0 → 1.1.0, `schema_version` deliberately unchanged), and the v0.2 label file declares `taxonomy_content_version`. The formal acceptance entry (`comqutor_alpha/regression/acceptance_engine.py: effective_rules`) reports a configuration error when the two differ, when the label file does not fit the taxonomy that was named, or when a ticker block carries a rule key the engine does not implement.
  - *Label alignment:* the five pairs of John's frozen baseline (`v0_2_john_frozen_gold_baseline.yaml`, authority `JOHN_WRITTEN_V0_2_BASELINE`) that no repo rule file carried (QQQ `A003__A501` and `A304__A601`, MSFT `A101__A304` and `A301__A304`, TSM `A101__A304`) were added to `allowed_conflicts` — John files all 16 pairs under `allowed_main_conflicts`, whose equivalent field is `allowed_conflicts` (never mandatory; absence is never a failure and raises no review). The ten pairs already under `conditional_conflicts` were left as they were. **Open question for John:** whether all 16 should be `allowed_conflicts`; moving the ten would turn SNDK from `needs_review` to `pass` (conditional pairs feed `should_detect_if_supported`).
  - *First real-data look at the two pairs* (frozen-input recompute of the six pinned historical runs, no model calls; `docs/audit_artifacts/round_source_linking_t0_t2/round23_t2_completion_20261007/frozen_input_recompute/`): `A201__A304` is admitted by the unchanged evidence gate on TSM and AMD (and is not the main conflict on either); `A102__A304` and the other `A201__A304` evaluations stay candidates with explicit reason codes, or never reach arbitration. On the older MSFT run `6cd2566d` the gate admits `A102__A304` and it becomes the recomputed main conflict. Evaluable never forced either outcome; the evidence did.
  - *Tests re-pinned for this change (taxonomy hash only; no other pin, no assertion removed, no skip added):* `test_msft_a102_a304_taxonomy_adjudication`, `test_evidence_review_v2` (taxonomy case), `test_step10_final_e2e_qa`, `test_step11_provider_health_rerun`, `test_high_value_unclassified_recovery`; and `test_v0_1_3_offline_replay_proof` now expects the newly evaluable `A102__A304` on the MSFT run it replays.

## PD-018 — Evidence trigger of the Gold v0.2 Alpha rules for runs other than the six the frozen trigger matrix is bound to

- **Status:** `OPEN` — needs the project owner (John). Recorded 2026-10-07, T2 gap closure (round 24).
- **Source:** `comqutor_alpha/regression/gold_contract_rules.py` executes five rules of John's frozen contract (`v0_2_gold_operational_contract.json`): `NVDA-A101-AI-GROWTH`, `NVDA-A304-VALUATION-RISK`, `MSFT-A102-DIRECT-INFERENCE-TRIGGER` (`must_detect_if_evidence_present`) and the NVDA / AMD growth-vs-valuation composites (`conditional_only`, "any ONE allowed pair"). Their evidence condition ("the defining current-evidence condition is present") was decided once, by reading `structured_agent_outputs.json` of ONE run per ticker, and recorded in `v0_2_evidence_trigger_matrix.json`.
- **Current handling:** the frozen trigger is used only for the run it is bound to. For any other run (a new Fresh run, a replay, a recovery / re-qualification run, the other saved runs) no approved, executable method determines the trigger, so each rule is `NOT_EVALUABLE` with the Alpha's identification, level and the contract requirement recorded next to it. A historical TRUE/FALSE is never carried over, and the ticker is never a PASS on top of an unevaluated rule.
- **Decision needed:** how the trigger is to be determined for another run — an approved executable method over the existing evidence authority (ticker-specific, qualified, role-aware, deduplicated fact groups, agent independence, structure support, stance), or a recorded per-run review. Also: the NVDA composite's `evidence_condition` is worded in terms of the component Alphas reaching a detected level, while the matrix and John's Step-4 protocol fix the trigger from evidence independent of the system's output; which reading applies to other runs.
- **Blocking phase:** none; until decided, a missed Alpha on a new run is recorded as facts and reported `not_evaluable`, not asserted as a FAIL.

## PD-019 — Pair-level `should_detect_if_supported` over `conditional_conflicts`

- **Status:** `OPEN` — needs the project owner (John). Recorded 2026-10-07.
- **Source:** John's frozen contract defines `should_detect_if_supported` for Alphas / structures (no conflict-pair rule uses it); his frozen baseline (`v0_2_john_frozen_gold_baseline.yaml`) lists the 16 ticker–pair relations as `allowed_main_conflicts`: "ALLOWED structures when supported by evidence -- never mandatory outputs". The label file carries ten of the 16 under `conditional_conflicts` (six from J2 v0.2 task section 8; four moved there by PD-017-REVISED / T2 item 1), and an engine reading of that bucket produced a review item when such a pair had a supporting fact on each side and was not admitted. No approval record backs that reading.
- **Current handling:** the reading is kept with its result, B2's own rejection reasons and its source, labelled `implementation_only_unapproved`, and decides NO formal status (`diagnostic_findings`). Effect on the saved runs: `docs/audit_artifacts/round_source_linking_t0_t2/round24_t2_gap_closure_20261007/before_after/delta_all_saved_runs.md`. The 16 pairs stay in the buckets they were in; nothing was moved. This overtakes the "open question for John" in the PD-017-REVISED addendum (round 23): SNDK's `pass` no longer depends on moving any pair, because the pair-level reading that produced SNDK's only review item decides nothing.
- **Decision needed:** whether any conflict pair is an independent detection expectation, and which; if none, whether the ten pairs should stay under `conditional_conflicts` or be carried as `allowed_conflicts`. The composite rules of the contract (NVDA, AMD) are the only conflict-level expectation with a documented basis, and they are executed.
- **Blocking phase:** none.

## PD-020 — `required_conflicts`: when a pair may be declared required

- **Status:** `OPEN` — needs the project owner (John). Recorded 2026-10-07.
- **Source:** J2 v0.2 task section 7: `required_conflicts` "only applies to an approved, complete, version-locked reference run; a miss may produce a regression failure". `labels_v2.load_j2_labels_v2` checks pair format, canonicality and mutual exclusivity only; neither it nor the acceptance engine checks that the label is approved or that the evaluated run is the reference run.
- **Current handling:** no ticker declares a required pair (`required_conflicts` is empty for all six). A required pair is judged from B2's own record: admitted → pass; evaluated and rejected for a recorded reason → not a miss; no usable record → not evaluated (review); only a record that meets every B2 condition and is still not admitted is a miss.
- **Decision needed:** the approval and reference-run binding a label must carry before `required_conflicts` may be non-empty, and whether the loader must refuse otherwise.
- **Blocking phase:** none while the list stays empty.

## PD-021 — The other fourteen Gold contract rules

- **Status:** `OPEN` — scope decision. Recorded 2026-10-07.
- **Source:** the frozen contract has 19 rules; the unified entry executes five (PD-018). The other fourteen — Alpha-level `should_detect_if_supported` / `conditional_only` rules (NVDA-A301, QQQ-A001 / A003 / A304 / A501 / A601, SNDK-A201, MSFT-A101 / A102-indirect / capex-burden), the two negative controls (`QQQ-ETF-CONTEXT-CONTROL`, `SNDK-ANTI-OVER-AI-CONTROL`), `NVDA-SUPPORTING-STRUCTURES` and the TSM transmission composite — are listed in `effective_rules.gold_contract.rules_not_in_effect` and are not evaluated.
- **Current handling:** a ticker's PASS covers only what the entry executes; `coverage.pass_scope_note` and `release.contract_rules_not_executed` say which contract rules it does not cover. For QQQ and SNDK six and two of those rules are blocking. John's own Step-4 table recorded QQQ run f88c8956 as FAIL (`QQQ-A001-RATE-CUT-CYCLE`); the unified entry shows that run as `pass` precisely because that rule is not executed — the two are not comparable.
- **Decision needed:** whether and in what order to execute the remaining rules (each needs its trigger from PD-018).
- **Blocking phase:** any claim that a ticker passes Gold v0.2.
